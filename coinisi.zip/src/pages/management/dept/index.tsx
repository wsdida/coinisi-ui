import {Button, Col, Input, InputNumber, Layout, Modal, Radio, Row, Space, Table, TreeSelect} from "antd";
import {DeleteOutlined, FileAddTwoTone} from "@ant-design/icons";
import {useState} from "react";
import styles from './index.less'


const columns = [
  {
    title: '部门名称',
    dataIndex: 'name',
    key: 'name',

  },
  {
    title: '排序',
    dataIndex: 'age',
    key: 'age',

  },
  {
    title: '状态',
    dataIndex: 'address',

    key: 'address',
  },
  {
    title: '创建时间',
    dataIndex: 'name',
    key: 'name',

  },
  {
    title: '操作',
    dataIndex: 'address',
    key: 'address',
    render: () =>
      <Space>
        <Button type={"link"} icon={<FileAddTwoTone />}>编辑</Button>
        <Button type={"link"} icon={<DeleteOutlined />}>删除</Button>
      </Space>
    ,
  },
];

const data = [
  {
    key: 1,
    name: 'John Brown sr.',
    age: 60,
    address: 'New York No. 1 Lake Park',
    children: [
      {
        key: 11,
        name: 'John Brown',
        age: 42,
        address: 'New York No. 2 Lake Park',
      },
      {
        key: 12,
        name: 'John Brown jr.',
        age: 30,
        address: 'New York No. 3 Lake Park',
        children: [
          {
            key: 121,
            name: 'Jimmy Brown',
            age: 16,
            address: 'New York No. 3 Lake Park',
          },
        ],
      },
      {
        key: 13,
        name: 'Jim Green sr.',
        age: 72,
        address: 'London No. 1 Lake Park',
        children: [
          {
            key: 131,
            name: 'Jim Green',
            age: 42,
            address: 'London No. 2 Lake Park',
            children: [
              {
                key: 1311,
                name: 'Jim Green jr.',
                age: 25,
                address: 'London No. 3 Lake Park',
              },
              {
                key: 1312,
                name: 'Jimmy Green sr.',
                age: 18,
                address: 'London No. 4 Lake Park',
              },
            ],
          },
        ],
      },
    ],
  },
  {
    key: 2,
    name: 'Joe Black',
    age: 32,
    address: 'Sidney No. 1 Lake Park',
  },
];
// rowSelection objects indicates the need for row selection
const rowSelection = {
  onChange: (selectedRowKeys: any, selectedRows: any) => {
    console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
  },
  onSelect: (record: any, selected: any, selectedRows: any) => {
    console.log(record, selected, selectedRows);
  },
  onSelectAll: (selected: any, selectedRows: any, changeRows: any) => {
    console.log(selected, selectedRows, changeRows);
  },
};

const treeData = [
  {
    title: 'Node1',
    value: '0-0',
    children: [
      {
        title: 'Child Node1',
        value: '0-0-1',
      },
      {
        title: 'Child Node2',
        value: '0-0-2',
      },
    ],
  },
  {
    title: 'Node2',
    value: '0-1',
  },
];
const Index: React.FC = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [deptState,setDeptState] = useState("0-0-1");

  // @ts-ignore
  return(
      <Layout>
      <Row>
        <Col span={24}>
          <Space align="center" style={{ marginBottom: 16 }}>
            <Button type={"primary"} onClick={() =>{setIsModalVisible(true)}}>添加</Button>
          </Space>
          <Table
            // @ts-ignore
            columns={columns}
            rowSelection={{ ...rowSelection}}
            dataSource={data}
          />
        </Col>
      </Row>
        <Modal title="Basic Modal" visible={isModalVisible} onOk={()=>{setIsModalVisible(false)}} onCancel={()=>{setIsModalVisible(false)}}>
          <Space direction={"vertical"}>
          <Space  direction={"vertical"}>
            <TreeSelect
              className={styles.input}
              defaultValue={'请选择上级部门'}
              value={deptState}
              dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
              treeData={treeData}
              placeholder="选择上级部门"
              treeDefaultExpandAll
              onChange={item =>{
                console.log(item)
                setDeptState(item)
              }}
            />

            <Input placeholder={"输入部门名称"}  className={styles.input}/>
            <Input placeholder={"输入负责人"}  className={styles.input}/>
            <Input placeholder={"联系电话"}  className={styles.input}/>
            <Input placeholder={"邮箱"}  className={styles.input}/>
            <InputNumber placeholder={"路由地址"}  min={1} max={1000} defaultValue={1} className={styles.input}/>
            <Radio.Group defaultValue="a" buttonStyle="solid">
              <Radio.Button value="a">正常</Radio.Button>
              <Radio.Button value="b">禁用</Radio.Button>
            </Radio.Group>
          </Space>
          </Space>
        </Modal>
      </Layout>
  );
};






export default Index;
