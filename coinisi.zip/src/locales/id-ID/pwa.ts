export default {
  'app.pwa.offline': 'Koneksi anda terputus',
  'app.pwa.serviceworker.updated': 'Konten baru sudah tersedia',
  'app.pwa.serviceworker.updated.hint':
    'Silahkan klik tombol "Refresh" untuk memuat ulang halaman ini',
  'app.pwa.serviceworker.updated.ok': 'Memuat ulang',
};
