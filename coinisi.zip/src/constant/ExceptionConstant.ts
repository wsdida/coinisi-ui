
export const enum  ExceptionConstant {


};
