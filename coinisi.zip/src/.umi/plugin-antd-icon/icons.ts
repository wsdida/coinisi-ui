// @ts-nocheck

import SmileOutlined from '@ant-design/icons/SmileOutlined';
import CrownOutlined from '@ant-design/icons/CrownOutlined';
import TableOutlined from '@ant-design/icons/TableOutlined'

export default {
  SmileOutlined,
CrownOutlined,
TableOutlined
}
    