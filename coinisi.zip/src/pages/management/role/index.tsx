
import {Button, Col, Input, Layout, Modal, Row, Select, Space, Table, TreeSelect} from "antd";
import {DeleteOutlined, EyeOutlined, SearchOutlined} from "@ant-design/icons";
import React from "react";

const { Option } = Select;

const data :any = [];
for (let i = 0; i < 46; i++) {
  data.push({
    key: i,
    name: `Edward King ${i}`,
    age: 32,
    address: `London, Park Lane no. ${i}`,
  });
}





const rowSelection = {
  onChange: (selectedRowKeys: any, selectedRows: any) => {
    console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
  },
  onSelect: (record: any, selected: any, selectedRows: any) => {
    console.log(record, selected, selectedRows);
  },
  onSelectAll: (selected: any, selectedRows: any, changeRows: any) => {
    console.log(selected, selectedRows, changeRows);
  },
};
const Role: React.FC = () => {
  const [checkStrictly] = React.useState(false);
  const [visible, setVisible] = React.useState(false);
  const [confirmLoading, setConfirmLoading] = React.useState(false);
  const [role,setRole] = React.useState(false)
  const [status,setStatus] = React.useState(undefined);
  const showModal = () => {
    setVisible(true);
  };

  const handleOk = () => {
    setConfirmLoading(true);
    setTimeout(() => {
      setVisible(false);
      setConfirmLoading(false);
    }, 2000);
  };
  const treeData = [
    {
      title: 'Node1',
      value: '0-0',
      children: [
        {
          title: 'Child Node1',
          value: '0-0-1',
        },
        {
          title: 'Child Node2',
          value: '0-0-2',
        },
      ],
    },
    {
      title: 'Node2',
      value: '0-1',
    },
  ];
  const handleCancel = () => {
    console.log('Clicked cancel button');
    setVisible(false);
  };
  const columns = [
    {
      title: '序号',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '角色名称',
      dataIndex: 'age',
      key: 'age',
    },
    {
      title: '角色标识',
      dataIndex: 'address',
      key: 'address',
    },  {
      title: '角色描述',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '数据权限',
      dataIndex: 'age',
      key: 'age',
    },
    {
      title: '创建时间',
      dataIndex: 'address',
      key: 'address',
    },
    ,
    {
      title: '操作',
      dataIndex: 'address',
      key: 'address',
      render: () => (
        <Space align={"center"} style={{width:'200px'}}>
          <Button type={"link"} icon={<EyeOutlined />}>查看</Button>
          <Button type={"link"} icon={<EyeOutlined />}>编辑</Button>
          <Button type={"link"} icon={<EyeOutlined /> }  onClick={()=>{setRole(true)}}>权限</Button>
          <Button type={"link"} icon={<EyeOutlined />}>删除</Button>
        </Space>
      ),

    },
  ];

  return(

      <Layout  >
        <Row  gutter={130}>
          <Col><Input type={"primary"} placeholder={"请输入角色名称"} style={{width:'150%'}}/></Col>
          <Col><Input type={"primary"} placeholder={"请输入角色标识"} style={{width:'150%'}}/></Col>
          <Col >
            <Select defaultValue="all" style={{width: '230px'}} onChange={item =>{console.log(item)}} >
             <Option value={"all"}>全部</Option>
            <Option value={"custom"}>自定义</Option>
            <Option value={"level"}>本级</Option>
            <Option value={"levelChild"}>本级及子级</Option>

          </Select></Col>
          <Col ><Button type={"primary"} icon={<SearchOutlined />} style={{marginLeft: '-110px'}}>搜索</Button></Col>
          <Col><Button type={"primary"} icon={<DeleteOutlined />} style={{marginLeft: '-130px'}}>清空</Button></Col>
        </Row>
        <Row >
          <Col>
            <Button type={"primary"}onClick={showModal}>添加</Button>
          </Col>
        </Row>

            <Table align={"center"} bordered={true} rowSelection={{ ...rowSelection, checkStrictly }}
              // @ts-ignore
                   columns={columns} dataSource={data} />
        <Modal
          title="Title"
          visible={visible}
          onOk={handleOk}
          confirmLoading={confirmLoading}
          onCancel={handleCancel}
        >
          <p><Input placeholder={"请输入角色名称"} /></p>
          <p><Input placeholder={"请输入角色标志"} /></p>
          <p><Input.TextArea placeholder={"请输入角色描述"} /></p>
          <Select defaultValue="all" style={{width: '230px'}} onChange={item =>{console.log(item)}} >
            <Option value={"all"}>全部</Option>
            <Option value={"custom"}>自定义</Option>
            <Option value={"level"}>本级</Option>
            <Option value={"levelChild"}>本级及子级</Option>

          </Select>
        </Modal>
        <Modal
          title="Title"
          visible={role}
          onOk={()=>{setRole(false)}}
          confirmLoading={confirmLoading}
          onCancel={()=>{setRole(false)}}
        >
          <TreeSelect
            style={{ width: '100%' }}
            value={status}
            dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
            treeData={treeData}
            placeholder="Please select"
            treeDefaultExpandAll
            onChange={()=>{setStatus(status)}}
          />
        </Modal>
      </Layout>

 );
};

export  default Role;
