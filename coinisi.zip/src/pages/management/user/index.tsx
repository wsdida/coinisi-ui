import styles from './index.less';
import React, {useState} from "react";
import {Button, Col,  Input, Layout,  message, Modal, Radio, Row, Space, Table, Tree} from "antd";
import {DeleteOutlined, DownOutlined,  SearchOutlined} from "@ant-design/icons";
import TreeSelect, { TreeNode } from 'antd/lib/tree-select';


const columns = [
  {
    align: 'center',
    title: '序号',
    dataIndex: 'id',
    key: 'id',
  },
  {
    align: 'center',
    title: '用户名',
    dataIndex: 'username',
    key: 'username',
  },
  {
    align: 'center',
    title: '昵称',
    dataIndex: 'nickname',
    key: 'nickname',
  },
  {
    align: 'center',
    title: '性别',
    dataIndex: 'gender',
    key: 'gender',
  },
  {
    align: 'center',
    title: '密码',
    dataIndex: 'password',
    key: 'password',
  },
  {
    align: 'center',
    title: '部门',
    dataIndex: 'dept_id',
    key: 'dept_id',
  },
  {
    align: 'center',
    title: '手机号',
    dataIndex: 'mobile',
    key: 'mobile',
  },
  {
    align: 'center',
    title: '邮箱',
    dataIndex: 'email',
    key: 'email',
  },
  {
    align: 'center',
    title: '头像',
    dataIndex: 'avatar',
    key: 'avatar',
  },
  {
    align: 'center',
    title: '角色',
    dataIndex: 'name',
    key: 'name',
  },
  {
    align: 'center',
    title: '状态',
    dataIndex: 'status',
    key: 'status',
  },
  {
    align: 'center',
    title: '创建时间',
    dataIndex: 'gmt_create',
    key: 'gmt_create',
  },
  {
    align: 'center',
    title: '操作',
    dataIndex: 'email',
    key: 'email',
    render: () => (
      <Space size="middle">
        <Button type={"link"}>编辑</Button>
        <Button type={"link"}>删除</Button>
      </Space>
    ),
  }
];

const data:  any[] | undefined = [];
// eslint-disable-next-line no-plusplus
for (let i = 0; i < 46; i++) {
  data.push({
    key: i,
    name: `Edward King ${i}`,
    age: 32,
    address: `London, Park Lane no. ${i}`,
  });
}// rowSelection objects indicates the need for row selection
const rowSelection = {
  onChange: (selectedRowKeys: any, selectedRows: any) => {
    console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
  },
  onSelect: (record: any, selected: any, selectedRows: any) => {
    console.log(record, selected, selectedRows);
  },
  onSelectAll: (selected: any, selectedRows: any, changeRows: any) => {
    console.log(selected, selectedRows, changeRows);
  },
};
// @ts-ignore
const onClick = ({ key }) => {
  message.info(`Click on item ${key}`);
};

const User: React.FC = () => {
  const [visible, setVisible] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [checkStrictly] = React.useState(false);
  const [value, setValue] = React.useState(0);

  // @ts-ignore
  return(
   <Layout>
     <Row gutter={[10,20]}  align={'top'}>
       <Col  span={4} >
         <Tree showLine
               switcherIcon={<DownOutlined />}
               defaultExpandedKeys={['0-0-0']}
               treeData={[
                 {
                   title: 'parent 1',
                   key: '0-0',
                   children: [
                     {
                       title: 'parent 1-0',
                       key: '0-0-0',
                       children: [
                         {
                           title: 'leaf',
                           key: '0-0-0-0',
                         },
                         {
                           title: 'leaf',
                           key: '0-0-0-1',
                         },
                         {
                           title: 'leaf',
                           key: '0-0-0-2',
                         },
                       ],
                     },
                     {
                       title: 'parent 1-1',
                       key: '0-0-1',
                       children: [
                         {
                           title: 'leaf',
                           key: '0-0-1-0',
                         },
                       ],
                     },
                     {
                       title: 'parent 1-2',
                       key: '0-0-2',
                       children: [
                         {
                           title: 'leaf',
                           key: '0-0-2-0',
                         },
                         {
                           title: 'leaf',
                           key: '0-0-2-1',
                         },
                       ],
                     },
                   ],
                 },
               ]}
         />

       </Col>
       <Col span={20} className={styles.col}>
         <Row>
           <Col>
             <Space style={{ marginBottom: 8 ,marginTop: 13}} size={20}>

               <Input style={{marginLeft:'10px'}} id={"userId"}  defaultValue={"请输入用户名"}/>
               <Input style={{marginLeft:'6px'}} id={"userId"}  defaultValue={"请输入手机号码"}/>
               <Input style={{marginLeft:'1px'}} id={"userId"}  defaultValue={"请输入状态"}/>
               <Button style={{marginLeft:'-15px'}} icon={<SearchOutlined />} type="primary" >查询</Button>
               <Button style={{ marginLeft: '-13px'}} icon={<DeleteOutlined />} type="primary">重置</Button>


             </Space>
           </Col>

         </Row>
          <Row>
            <Col>

              <Space style={{ marginBottom: 8, marginLeft: 10,}}>
                <Button type={"ghost"}  onClick={() => setVisible(true)}>添加</Button>
                <Button type={"ghost"}>角色配置</Button>
                <Button type={"ghost"}>导入</Button>
                <Button type={"ghost"}>导出</Button>

              </Space>
            </Col>
          </Row>

        <Table bordered={true} rowSelection={{ ...rowSelection, checkStrictly }}
          // @ts-ignore
               columns={columns} dataSource={data} />
       </Col>
     </Row>
     <Modal
       title="添加用户"
       centered
       visible={visible}
       onOk={() => setVisible(false)}
       onCancel={() => setVisible(false)}

     >
      <Space direction={"vertical"}>
        <Row><Col span={4}>用户名：</Col><Col span={8}><Input bordered={true}/></Col>
          <Col span={4} ><text>昵称:</text></Col><Col span={8}><Input bordered={true}/></Col>
        </Row>
        <Row><Col span={4}>性别:</Col><Col span={8}>
          <Radio.Group onChange={() =>{setValue(value)}} value={value}>
          <Radio value={1}>男</Radio>
          <Radio value={2}>女</Radio>
        </Radio.Group></Col>
          <Col span={4} style={{marginLeft:0}}>密码:</Col><Col span={8}><Input bordered={true}/></Col>
        </Row>
        <Row><Col span={4}>部门:</Col><Col span={8}>
          <TreeSelect
            showSearch
            style={{ width: '100%' }}
            value={value}
            dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
            placeholder="Please select"
            allowClear
            treeDefaultExpandAll
            onChange={() =>{
            // @ts-ignore
              setValueTree(value)}
            }
          >
            <TreeNode value="parent 1" title="parent 1">
              <TreeNode value="parent 1-0" title="parent 1-0">
                <TreeNode value="leaf1" title="leaf1" />
                <TreeNode value="leaf2" title="leaf2" />
              </TreeNode>
              <TreeNode value="parent 1-1" title="parent 1-1">
                <TreeNode value="leaf3" title={<b style={{ color: '#08c' }}>leaf3</b>} />
              </TreeNode>
            </TreeNode>
          </TreeSelect>
       </Col>
          <Col span={4}>手机号:</Col><Col span={8}><Input bordered={true}/></Col>
        </Row>
        <Row><Col span={4}>邮箱:</Col><Col span={8}><Input bordered={true}/></Col>
          <Col span={4}>头像:</Col><Col span={8}><Input bordered={true}/></Col>
        </Row>
        <Row><Col span={4}>角色:</Col><Col span={8}> <TreeSelect
          showSearch
          style={{ width: '100%' }}
          value={value}
          dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
          placeholder="Please select"
          allowClear
          treeDefaultExpandAll
          onChange={() =>{
            // @ts-ignore
            setValueTree(value)}
          }
        >
          <TreeNode value="parent 1" title="parent 1">
            <TreeNode value="parent 1-0" title="parent 1-0">
              <TreeNode value="leaf1" title="leaf1" />
              <TreeNode value="leaf2" title="leaf2" />
            </TreeNode>
            <TreeNode value="parent 1-1" title="parent 1-1">
              <TreeNode value="leaf3" title={<b style={{ color: '#08c' }}>leaf3</b>} />
            </TreeNode>
          </TreeNode>
        </TreeSelect></Col>
          <Col span={4}>状态:</Col><Col span={8}> <Radio.Group onChange={() =>{setValue(value)}} value={value}>
            <Radio value={1}>正常</Radio>
            <Radio value={2}>锁定</Radio>
          </Radio.Group></Col>
        </Row>
      </Space>
     </Modal>
   </Layout>
 );
};

export  default User;
