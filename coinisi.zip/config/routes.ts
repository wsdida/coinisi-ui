﻿export default [
  {
    path: '/user',
    layout: false,
    routes: [
      {
        path: '/user',
        routes: [
          {
            name: 'login',
            path: '/user/login',
            component: './user/Login',
          },
        ],
      },
    ],
  },
  {
    path: "/manager/user",
    component: './management/user',
    name:'userManagement'
  },
  {
    path: "/admin/menu",
    component: './management/menu',
    name:'menu'
  },
  {
    path: "/manager/role",
    component: './management/role',
    name:'userManagement'
  }
  ,
  {
    path: "/manager/dept",
    component: './management/dept',
    name:'userManagement'
  }
  ,
  {
    path: "/manager/post",
    component: './management/post',
    name:'userManagement'
  }
  ,
  {
    path: "/manager/log",
    component: './management/log',
    name:'userManagement'
  }
  ,
  {
    path: "/manager/dictionary",
    component: './management/dictionary',
    name:'userManagement'
  },
  {
    path: '/welcome',
    name: 'welcome',
    icon: 'smile',
    component: './Welcome',
  },
  {
    path: '/admin',
    name: 'admin',
    icon: 'crown',

    component: './Admin',
    routes: [
      {
        path: '/admin/sub-page',
        name: 'sub-page',
        icon: 'smile',
        component: './Welcome',
      },
    ],
  },
  {
    name: 'list.table-list',
    icon: 'table',
    path: '/list',
    component: './TableList',
  },
  {
    path: '/',
    redirect: '/welcome',
  },
  {
    component: './404',
  },
];
