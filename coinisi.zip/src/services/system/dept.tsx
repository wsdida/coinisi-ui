import { request } from 'umi';
/** 获取部门树形化 GET /api/currentUser */
export async function selectTreeDept(options?: { [key: string]: any }) {
  return request<SYSTEM.SelectTree>('/coinisi/coinisi-system/sys-dept/getTree', {
    method: 'GET',
    ...(options || {}),
  });
}
