declare namespace SYSTEM {
  type SelectTree = {
    value?: string;
    title?: string;
    parentId?: number;
    children?: {
      value?: string;
      title?: string;
      parentId?: number;
    }[];
    deptStateVos?: {
      disabled?: string;
      disableCheckbox?: string;
      pselectable?: string;
      checkable?: string;
    }[];
  }
}
